const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const { Server } = require('socket.io');
const axios = require('axios');  // Import axios for HTTP requests

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Middleware
app.use(express.static('public')); // Serve static files
app.use(bodyParser.json()); // Parse JSON data from requests

// Variable to store sensor data
let sensorData = {};

// Fetch data from the Python server every 5 seconds
const fetchSensorDataFromPython = async () => {
    try {
        const response = await axios.get('http://localhost:5000/sensor-data'); // Python server URL
        if (response.data) {
            sensorData = response.data;  // Update sensor data
            io.emit('sensor-update', sensorData);  // Emit to connected clients
        }
    } catch (error) {
        console.error('Error fetching sensor data from Python server:', error);
    }
};

// Get sensor data
app.get('/api/sensors', (req, res) => {
    res.json(sensorData);  // Return the current sensor data
});

// Real-time communication with clients using Socket.io
io.on('connection', (socket) => {
    console.log('New client connected');
    socket.emit('sensor-update', sensorData);  // Send initial sensor data to new client

    // Handle client disconnection
    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

// Start the server and periodically fetch data from Python server
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    setInterval(fetchSensorDataFromPython, 5000); // Fetch data every 5 seconds
});
